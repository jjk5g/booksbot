<?php
$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['timezone'] ?? 'Australia/Brisbane');

function cfg(?string $key = null) {
    global $config;
    return $key === null ? $config : ($config[$key] ?? null);
}

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function now_sql(): string { return date('Y-m-d H:i:s'); }

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $d = cfg('db');
    $dsn = "mysql:host={$d['host']};port={$d['port']};dbname={$d['name']};charset=utf8mb4";
    $pdo = new PDO($dsn, $d['user'], $d['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    ensure_schema($pdo);
    return $pdo;
}

function ensure_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $pdo->exec("CREATE TABLE IF NOT EXISTS locations (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      slug VARCHAR(120) NOT NULL UNIQUE,
      region VARCHAR(80) NOT NULL DEFAULT 'Gold Coast',
      state VARCHAR(40) NOT NULL DEFAULT 'QLD',
      country VARCHAR(40) NOT NULL DEFAULT 'Australia',
      latitude DECIMAL(9,6) NOT NULL,
      longitude DECIMAL(9,6) NOT NULL,
      description TEXT NULL,
      seo_title VARCHAR(180) NULL,
      seo_description VARCHAR(320) NULL,
      active TINYINT(1) NOT NULL DEFAULT 1,
      featured TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_active_region (active, region)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS streams (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      location_id INT UNSIGNED NOT NULL,
      name VARCHAR(140) NOT NULL,
      stream_type VARCHAR(20) NOT NULL DEFAULT 'hls',
      stream_url TEXT NOT NULL,
      source_name VARCHAR(120) NULL,
      source_url TEXT NULL,
      active TINYINT(1) NOT NULL DEFAULT 1,
      sort_order INT NOT NULL DEFAULT 10,
      status VARCHAR(20) NOT NULL DEFAULT 'unknown',
      last_checked_at DATETIME NULL,
      last_alert_at DATETIME NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_stream_location FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
      INDEX idx_stream_location (location_id, active, sort_order),
      INDEX idx_stream_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS daily_views (
      location_id INT UNSIGNED NOT NULL,
      view_date DATE NOT NULL,
      views INT UNSIGNED NOT NULL DEFAULT 0,
      PRIMARY KEY(location_id, view_date),
      CONSTRAINT fk_views_location FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS stream_reports (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      stream_id INT UNSIGNED NULL,
      location_id INT UNSIGNED NOT NULL,
      reason VARCHAR(60) NOT NULL,
      message TEXT NULL,
      reporter_email VARCHAR(190) NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'open',
      ip_hash CHAR(64) NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      resolved_at DATETIME NULL,
      CONSTRAINT fk_report_stream FOREIGN KEY (stream_id) REFERENCES streams(id) ON DELETE SET NULL,
      CONSTRAINT fk_report_location FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
      INDEX idx_report_status_created (status, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS contacts (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NULL,
      email VARCHAR(190) NULL,
      subject VARCHAR(180) NULL,
      message TEXT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS forecast_cache (
      location_id INT UNSIGNED PRIMARY KEY,
      fetched_at DATETIME NOT NULL,
      data_json MEDIUMTEXT NOT NULL,
      CONSTRAINT fk_forecast_location FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS news_items (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      url TEXT NOT NULL,
      source VARCHAR(120) NOT NULL,
      summary TEXT NULL,
      published_at DATETIME NULL,
      active TINYINT(1) NOT NULL DEFAULT 1,
      featured TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_news_title_source (title, source)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    seed_if_empty($pdo);
}

function seed_if_empty(PDO $pdo): void {
    if ((int)$pdo->query("SELECT COUNT(*) FROM locations")->fetchColumn() > 0) return;

    $locations = [
      ['Bilinga / Tugun','bilinga-tugun','Gold Coast','QLD',-28.1607,153.5105,1,'Live surf camera for Bilinga and Tugun on the southern Gold Coast. Check the beach before you go.'],
      ['Burleigh Heads','burleigh-heads','Gold Coast','QLD',-28.0904,153.4559,1,'Watch Burleigh Heads live and check current wave and weather conditions at one of the Gold Coast’s best-known surf locations.'],
      ['Coolangatta / Greenmount / Rainbow Bay','coolangatta-greenmount-rainbow-bay','Gold Coast','QLD',-28.1666,153.5449,1,'Live view across Coolangatta, Greenmount and Rainbow Bay near the Superbank.'],
      ['Currumbin Alley','currumbin-alley','Gold Coast','QLD',-28.1251,153.4822,1,'Currumbin Alley live beach camera and surf conditions.'],
      ['Froggies / Tweed River','froggies-tweed-river','Tweed Coast','NSW',-28.1702,153.5505,0,'Live views around the Tweed River entrance and Froggies area.'],
      ['Kirra','kirra','Gold Coast','QLD',-28.1682,153.5296,1,'Kirra live surf camera, wave conditions and forecast.'],
      ['Kurrawa','kurrawa','Gold Coast','QLD',-28.0292,153.4348,0,'Kurrawa Beach live camera and forecast.'],
      ['Main Beach','main-beach','Gold Coast','QLD',-27.9788,153.4321,0,'Main Beach Gold Coast live camera and beach conditions.'],
      ['Miami Beach','miami-beach','Gold Coast','QLD',-28.0696,153.4430,0,'Miami Beach Gold Coast live camera and surf forecast.'],
      ['Narrowneck','narrowneck','Gold Coast','QLD',-27.9955,153.4304,0,'Narrowneck live camera including high view and artificial reef conditions.'],
      ['Northcliffe','northcliffe','Gold Coast','QLD',-28.0113,153.4320,0,'Northcliffe and Surfers Paradise high camera.'],
      ['Palm Beach','palm-beach','Gold Coast','QLD',-28.1167,153.4710,0,'Palm Beach Gold Coast live surf camera and forecast.'],
      ['Gold Coast Seaway / The Spit','gold-coast-seaway','Gold Coast','QLD',-27.9395,153.4280,0,'Multiple live views around the Gold Coast Seaway and The Spit.'],
      ['Sea World / Spit South','sea-world-spit','Gold Coast','QLD',-27.9578,153.4266,0,'Live camera near Sea World and the southern Spit.'],
      ['Surfers Paradise','surfers-paradise','Gold Coast','QLD',-28.0026,153.4304,1,'Surfers Paradise live beach camera, current conditions and surf forecast.'],
      ['Tallebudgera','tallebudgera','Gold Coast','QLD',-28.1025,153.4554,0,'Tallebudgera live beach camera and surf conditions.'],
      ['Kingscliff / Cudgen','kingscliff','Tweed Coast','NSW',-28.2565,153.5780,1,'Kingscliff and Cudgen live coastal bar camera with local marine and weather forecast.'],
      ['Cabarita Beach','cabarita-beach','Tweed Coast','NSW',-28.3310,153.5704,1,'Cabarita Beach surf forecast and nearby live camera coverage on the Tweed Coast.'],
      ['Hastings Point','hastings-point','Tweed Coast','NSW',-28.3648,153.5774,0,'Hastings Point surf and marine forecast with nearby live camera coverage.'],
      ['Pottsville Beach','pottsville-beach','Tweed Coast','NSW',-28.3884,153.5660,0,'Pottsville Beach surf forecast and nearby live camera coverage.'],
      ['Tweed Heads','tweed-heads','Tweed Coast','NSW',-28.1720,153.5510,1,'Official live coastal camera showing offshore conditions near the Tweed River entrance.'],
      ['Tweed Heads Entrance','tweed-heads-entrance','Tweed Coast','NSW',-28.1710,153.5500,1,'Official live camera inside the Tweed Heads entrance channel.'],
      ['Brunswick Heads','brunswick-heads','Northern Rivers','NSW',-28.5407,153.5520,0,'Official live coastal bar camera and forecast for Brunswick Heads.'],
    ];
    $st = $pdo->prepare("INSERT INTO locations(name,slug,region,state,latitude,longitude,featured,description,seo_title,seo_description) VALUES(?,?,?,?,?,?,?,?,?,?)");
    foreach ($locations as $l) {
        [$name,$slug,$region,$state,$lat,$lon,$featured,$desc] = $l;
        $title = "$name Live Surf Cam & Forecast | CostaCams";
        $seo = "$name live beach camera, surf forecast, wave height, swell period, wind and local conditions on CostaCams.";
        $st->execute([$name,$slug,$region,$state,$lat,$lon,$featured,$desc,$title,$seo]);
    }
    $ids = [];
    foreach ($pdo->query("SELECT id,slug FROM locations") as $r) $ids[$r['slug']] = $r['id'];

    $streams = [
      ['bilinga-tugun','Bilinga / Tugun','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/tuguncamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['burleigh-heads','Burleigh Heads – High','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/burleighhighcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['burleigh-heads','Burleigh Heads – Headland','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/burleighheadscamera.stream/playlist.m3u8','Gold Coast camera feed',null,20],
      ['coolangatta-greenmount-rainbow-bay','Rainbow Bay / Greenmount','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/rainbowbaycamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['currumbin-alley','Currumbin Alley','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/currumbincamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['froggies-tweed-river','Tweed River Static','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/tweedriverstaticcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['froggies-tweed-river','Tweed River Bar','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/tweedriverbarcamera.stream/playlist.m3u8','Gold Coast camera feed',null,20],
      ['kirra','Kirra','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/kirracamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['kurrawa','Kurrawa','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/kurrawacamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['main-beach','Main Beach','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/mainbeachcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['miami-beach','Miami','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/miamicamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['narrowneck','Narrowneck – High','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/narrowneckhighcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['narrowneck','Narrowneck – Artificial Reef','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/artreefcamera.stream/playlist.m3u8','Gold Coast camera feed',null,20],
      ['northcliffe','Northcliffe / Surfers Paradise – High','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/surfersparadisehighcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['palm-beach','Palm Beach','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/palmbeachqldcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['gold-coast-seaway','Seaway – Spit','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/seawayspitcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['gold-coast-seaway','Seaway – Pole','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/seawaypolecamera.stream/playlist.m3u8','Gold Coast camera feed',null,20],
      ['gold-coast-seaway','Seaway – Jetty','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/seawayjettycamera.stream/playlist.m3u8','Gold Coast camera feed',null,30],
      ['sea-world-spit','Sea World / Spit South','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/seaworldcamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['surfers-paradise','Surfers Paradise – Main','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/surfersparadisecamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['tallebudgera','Tallebudgera','hls','https://d1nm4r8e5x1rwd.cloudfront.net/cw/tallebudgeracamera.stream/playlist.m3u8','Gold Coast camera feed',null,10],
      ['kingscliff','Cudgen / Kingscliff Coastal Bar','iframe','https://widget.coastalcoms.com/video/73a52fac-d291-42be-a1f1-dd859c5dd28f','Transport for NSW','https://www.nsw.gov.au/driving-boating-and-transport/using-waterways-boating-and-transport-information/conditions-weather-and-tides/webcams/cudgen',10],
      ['tweed-heads','Tweed Heads Offshore','iframe','https://widget.coastalcoms.com/video/ebe03351-5116-4987-9e59-52776a7b3af2','Transport for NSW','https://www.nsw.gov.au/driving-boating-and-transport/using-waterways-boating-and-transport-information/conditions-weather-and-tides/webcams/tweed-heads',10],
      ['tweed-heads-entrance','Tweed Heads Entrance','iframe','https://widget.coastalcoms.com/video/6321b2c5-7545-49d1-83b3-a10fd2c8926b','Transport for NSW','https://www.nsw.gov.au/driving-boating-and-transport/using-waterways-boating-and-transport-information/conditions-weather-and-tides/webcams/tweed-heads-entrance',10],
      ['brunswick-heads','Brunswick Heads Coastal Bar','iframe','https://widget.coastalcoms.com/video/db6bcca9-545e-4575-95ee-a5b1d4786f63','Transport for NSW','https://www.nsw.gov.au/driving-boating-and-transport/using-waterways-boating-and-transport-information/conditions-weather-and-tides/webcams/brunswick-heads',10],
    ];
    $ss = $pdo->prepare("INSERT INTO streams(location_id,name,stream_type,stream_url,source_name,source_url,sort_order) VALUES(?,?,?,?,?,?,?)");
    foreach ($streams as $s) {
        [$slug,$name,$type,$url,$source,$sourceUrl,$sort] = $s;
        if (isset($ids[$slug])) $ss->execute([$ids[$slug],$name,$type,$url,$source,$sourceUrl,$sort]);
    }

    $news = [
      ['Milla Coco Brown and Willem Watson Win Noosa Pro Junior','https://surfingqueensland.com.au/news/','Surfing Queensland','Latest Queensland professional and junior surf competition news.','2026-09-01 09:00:00'],
      ['Champions Emerge at 21st Billabong Occy’s Grom Comp','https://surfingqueensland.com.au/news/','Surfing Queensland','Competition wrapped at Snapper Rocks with clean surf and strong junior performances.','2026-07-06 09:00:00'],
      ['Queensland Team Locked In After Gold Coast Grand Final','https://surfingqueensland.com.au/news/','Surfing Queensland','Gold Coast grand final results and Queensland team selection.','2026-06-15 09:00:00'],
      ['Queenslanders Stephanie Gilmore and Ethan Ewing Win Gold Coast Pro','https://surfingqueensland.com.au/news/','Surfing Queensland','Gold Coast Pro results from Snapper Rocks.','2026-05-05 09:00:00'],
      ['2026 Gold Coast Open at Burleigh Heads','https://surfingqueensland.com.au/news/','Surfing Queensland','Coverage and results from the Gold Coast Open at Burleigh Heads.','2026-02-23 09:00:00'],
    ];
    $ns = $pdo->prepare("INSERT IGNORE INTO news_items(title,url,source,summary,published_at,active,featured) VALUES(?,?,?,?,?,1,1)");
    foreach ($news as $n) $ns->execute($n);
}

function get_location_by_slug(string $slug): ?array {
    $st=db()->prepare("SELECT * FROM locations WHERE slug=? AND active=1 LIMIT 1");
    $st->execute([$slug]);
    return $st->fetch() ?: null;
}
function get_streams(int $locationId, bool $onlyActive=true): array {
    $sql="SELECT * FROM streams WHERE location_id=?" . ($onlyActive?" AND active=1":"") . " ORDER BY sort_order,id";
    $st=db()->prepare($sql); $st->execute([$locationId]); return $st->fetchAll();
}
function get_locations(bool $active=true): array {
    return db()->query("SELECT l.*, (SELECT COUNT(*) FROM streams s WHERE s.location_id=l.id AND s.active=1) stream_count FROM locations l ".($active?"WHERE l.active=1 ":"")."ORDER BY region,name")->fetchAll();
}
function increment_view(int $locationId): void {
    $st=db()->prepare("INSERT INTO daily_views(location_id,view_date,views) VALUES(?,CURDATE(),1) ON DUPLICATE KEY UPDATE views=views+1");
    $st->execute([$locationId]);
}
function popular_locations(int $days=30,int $limit=8): array {
    $days=max(1,min(365,$days)); $limit=max(1,min(24,$limit));
    $sql="SELECT l.*, COALESCE(SUM(v.views),0) views FROM locations l LEFT JOIN daily_views v ON v.location_id=l.id AND v.view_date>=DATE_SUB(CURDATE(), INTERVAL {$days} DAY) WHERE l.active=1 GROUP BY l.id ORDER BY views DESC,l.featured DESC,l.name LIMIT {$limit}";
    return db()->query($sql)->fetchAll();
}

function http_json(string $url,int $timeout=8): ?array {
    $ctx=stream_context_create(['http'=>['timeout'=>$timeout,'user_agent'=>'CostaCams/2.0 (+https://costacams.com)']]);
    $raw=@file_get_contents($url,false,$ctx);
    if ($raw===false && function_exists('curl_init')) {
        $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>'CostaCams/2.0']);
        $raw=curl_exec($ch); curl_close($ch);
    }
    if (!$raw) return null;
    $data=json_decode($raw,true); return is_array($data)?$data:null;
}

function get_forecast(array $loc): array {
    $pdo=db();
    $st=$pdo->prepare("SELECT data_json,fetched_at FROM forecast_cache WHERE location_id=?"); $st->execute([$loc['id']]); $row=$st->fetch();
    if ($row && strtotime($row['fetched_at']) > time()-1200) {
        $d=json_decode($row['data_json'],true); if(is_array($d)) return $d;
    }
    $lat=(float)$loc['latitude']; $lon=(float)$loc['longitude'];
    $c=cfg(); $commercial=!empty($c['open_meteo_commercial']) && !empty($c['open_meteo_key']);
    $marineBase=$commercial?'https://customer-marine-api.open-meteo.com/v1/marine':'https://marine-api.open-meteo.com/v1/marine';
    $weatherBase=$commercial?'https://customer-api.open-meteo.com/v1/forecast':'https://api.open-meteo.com/v1/forecast';
    $key=$commercial?'&apikey='.rawurlencode($c['open_meteo_key']):'';
    $tz='Australia%2FBrisbane';
    $marine=http_json($marineBase.'?latitude='.$lat.'&longitude='.$lon.'&daily=wave_height_max,wave_direction_dominant,wave_period_max,swell_wave_height_max,swell_wave_period_max&timezone='.$tz.'&forecast_days=7'.$key);
    $weather=http_json($weatherBase.'?latitude='.$lat.'&longitude='.$lon.'&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant&timezone='.$tz.'&forecast_days=7'.$key);
    $out=['days'=>[],'updated'=>date(DATE_ATOM),'ok'=>false];
    $dates=$weather['daily']['time'] ?? ($marine['daily']['time'] ?? []);
    foreach($dates as $i=>$date){
        $out['days'][]=[
          'date'=>$date,
          'weather_code'=>$weather['daily']['weather_code'][$i]??null,
          'temp_max'=>$weather['daily']['temperature_2m_max'][$i]??null,
          'temp_min'=>$weather['daily']['temperature_2m_min'][$i]??null,
          'rain'=>$weather['daily']['precipitation_probability_max'][$i]??null,
          'wind'=>$weather['daily']['wind_speed_10m_max'][$i]??null,
          'wind_dir'=>$weather['daily']['wind_direction_10m_dominant'][$i]??null,
          'wave'=>$marine['daily']['wave_height_max'][$i]??null,
          'wave_dir'=>$marine['daily']['wave_direction_dominant'][$i]??null,
          'period'=>$marine['daily']['wave_period_max'][$i]??null,
          'swell'=>$marine['daily']['swell_wave_height_max'][$i]??null,
          'swell_period'=>$marine['daily']['swell_wave_period_max'][$i]??null,
        ];
    }
    $out['ok']=count($out['days'])>0;
    if($out['ok']){
        $js=json_encode($out,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $up=$pdo->prepare("INSERT INTO forecast_cache(location_id,fetched_at,data_json) VALUES(?,NOW(),?) ON DUPLICATE KEY UPDATE fetched_at=NOW(),data_json=VALUES(data_json)"); $up->execute([$loc['id'],$js]);
    }
    return $out;
}

function compass($deg): string {
    if ($deg===null || $deg==='') return '—';
    $dirs=['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
    return $dirs[(int)round(((float)$deg)/22.5)%16];
}
function weather_icon($code): string {
    if($code===null) return '🌊'; $c=(int)$code;
    if($c===0) return '☀️'; if(in_array($c,[1,2],true)) return '🌤️'; if($c===3) return '☁️';
    if(in_array($c,[45,48],true)) return '🌫️'; if(in_array($c,[51,53,55,56,57,61,63,65,66,67,80,81,82],true)) return '🌧️';
    if(in_array($c,[71,73,75,77,85,86],true)) return '❄️'; if(in_array($c,[95,96,99],true)) return '⛈️'; return '🌤️';
}
function send_owner_mail(string $subject,string $body,?string $replyTo=null): bool {
    $to=cfg('owner_email'); $from=cfg('mail_from');
    $headers=['MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','From: CostaCams <'.$from.'>'];
    if($replyTo && filter_var($replyTo,FILTER_VALIDATE_EMAIL)) $headers[]='Reply-To: '.$replyTo;
    return @mail($to,$subject,$body,implode("\r\n",$headers));
}
function csrf_token(): string {
    if(session_status()!==PHP_SESSION_ACTIVE) session_start();
    if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf'];
}
function check_csrf(): bool {
    if(session_status()!==PHP_SESSION_ACTIVE) session_start();
    return isset($_POST['csrf'],$_SESSION['csrf']) && hash_equals($_SESSION['csrf'],(string)$_POST['csrf']);
}
function visitor_hash(): string {
    $ip=$_SERVER['REMOTE_ADDR']??''; return hash('sha256',date('Y-m-d').'|'.$ip.'|CostaCams');
}
function site_news(int $limit=6): array {
    $st=db()->prepare("SELECT * FROM news_items WHERE active=1 ORDER BY COALESCE(published_at,created_at) DESC LIMIT ?"); $st->bindValue(1,$limit,PDO::PARAM_INT); $st->execute(); return $st->fetchAll();
}
