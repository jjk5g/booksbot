<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/lib.php';
// Best-effort RSS import. Fails silently and leaves manually managed news intact.
$feeds=[['Surfing Queensland','https://surfingqueensland.com.au/feed/'],['Surfing Australia','https://surfingaustralia.com/feed/']];
foreach($feeds as [$source,$url]){
  $ctx=stream_context_create(['http'=>['timeout'=>12,'user_agent'=>'CostaCams/2.0']]);$raw=@file_get_contents($url,false,$ctx);if(!$raw)continue;libxml_use_internal_errors(true);$xml=simplexml_load_string($raw);if(!$xml||empty($xml->channel->item))continue;
  $st=db()->prepare("INSERT IGNORE INTO news_items(title,url,source,summary,published_at,active,featured) VALUES(?,?,?,?,?,1,1)");$i=0;foreach($xml->channel->item as $item){if($i++>=10)break;$title=trim((string)$item->title);$link=trim((string)$item->link);$desc=trim(strip_tags((string)$item->description));$desc=mb_substr(preg_replace('/\s+/',' ',$desc),0,260);$date=(string)$item->pubDate;$published=$date?date('Y-m-d H:i:s',strtotime($date)):null;$st->execute([$title,$link,$source,$desc,$published]);}
}
