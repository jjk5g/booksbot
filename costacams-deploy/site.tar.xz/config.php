<?php
// Server-side configuration. Sensitive values live in secrets.php and are never exposed in HTML/JS.
$secrets = require __DIR__ . '/secrets.php';
return [
    'db' => [
        'host' => 'srv929.hstgr.io',
        'port' => 3306,
        'name' => 'u751177156_costacamsweb',
        'user' => 'u751177156_costaweb',
        'pass' => $secrets['db_pass'] ?? '',
    ],
    'owner_email' => $secrets['owner_email'] ?? '',
    'site_url' => 'https://costacams.com',
    'mail_from' => 'noreply@costacams.com',
    'timezone' => 'Australia/Brisbane',
    // Evaluation endpoint by default. Configure a commercial key before monetising.
    'open_meteo_key' => '',
    'open_meteo_commercial' => false,
];
