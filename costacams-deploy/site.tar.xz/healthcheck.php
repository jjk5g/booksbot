<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/lib.php';$pdo=db();$streams=$pdo->query("SELECT s.*,l.name location_name FROM streams s JOIN locations l ON l.id=s.location_id WHERE s.active=1")->fetchAll();
foreach($streams as $s){
  $url=$s['stream_url'];$ok=false;$code=0;$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_NOBODY=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_USERAGENT=>'CostaCams HealthCheck/1.0']);curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$ok=$code>=200&&$code<400;
  // Some video/widget servers reject HEAD. Retry a tiny GET.
  if(!$ok){$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_RANGE=>'0-1023',CURLOPT_USERAGENT=>'CostaCams HealthCheck/1.0']);curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$ok=$code>=200&&$code<400;}
  $new=$ok?'online':'offline';$old=$s['status'];$pdo->prepare("UPDATE streams SET status=?,last_checked_at=NOW() WHERE id=?")->execute([$new,$s['id']]);
  $recent=$s['last_alert_at'] && strtotime($s['last_alert_at'])>time()-21600;
  if(!$ok && $old!=='offline' && !$recent){send_owner_mail('[URGENT CostaCams] Camera appears offline',$s['location_name']." — ".$s['name']."\n\nAutomated health check failed with HTTP status {$code}.\n\nAdmin: ".cfg('site_url')."/admin");$pdo->prepare("UPDATE streams SET last_alert_at=NOW() WHERE id=?")->execute([$s['id']]);}
}
